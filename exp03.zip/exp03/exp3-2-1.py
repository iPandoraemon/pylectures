a, b, c = eval(input("输入a, b, c:"))
jc = max(a, b, c) - min(a, b, c)
print("极差="+str(jc))